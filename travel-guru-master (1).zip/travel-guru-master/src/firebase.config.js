const firebaseConfig = {
    apiKey: "AIzaSyBHMbbz-crrfODBvcJxqadGwk2RZTfH0g8",
    authDomain: "travel-guru-a.firebaseapp.com",
    databaseURL: "https://travel-guru-a.firebaseio.com",
    projectId: "travel-guru-a",
    storageBucket: "travel-guru-a.appspot.com",
    messagingSenderId: "56119632304",
    appId: "1:56119632304:web:402323327ec6f3c19d3675"
  };
  export default firebaseConfig