import React from 'react';
import Header from '../Header/Header'
import logoBlack from '../../images/Logo-black.png'
const Blog = () => {
    return (
        <div>
            <Header img={logoBlack} color="black"></Header>
            <h1>In Progress..</h1>
        </div>
    );
};

export default Blog;